(() => {
  'use strict';

  const BOX_ID = 'ytcf-box';
  const BTN_TEXT = 'Сначала кириллица';
  const MIN_CYRILLIC_RATIO = 0.3;  // доля кириллицы среди букв
  const HIDE_FOREIGN = false;      // true — скрывать чужие полностью
  const DEFAULT_TARGET = 500;      // значение в поле по умолчанию
  const MAX_TARGET = 30000;        // потолок (защита от зависания вкладки)
  const MAX_ROUNDS = 2000;         // лимит подгрузок
  const LOAD_TIMEOUT_MS = 7000;    // сколько ждать новую порцию
  const MAX_STALLS = 4;            // таймаутов подряд = комментарии кончились
  const CANCEL_KEYS = ['Escape', 'n', 'N', 'т', 'Т']; // отмена: Esc или N (в т.ч. русская раскладка)
  const STORE_KEY = 'ytcf-target';

  let active = false;              // фильтр включён
  let phase = 'idle';              // idle | loading
  let runId = 0;                   // для отмены подгрузки
  let target = DEFAULT_TARGET;
  let timer = null;
  let sortedParent = null;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const log = (...a) => console.log('[YTCF]', ...a);
  const countThreads = () =>
    document.querySelectorAll('ytd-comments ytd-comment-thread-renderer').length;
  const pageBottom = () => document.documentElement.scrollHeight;

  try {
    const saved = parseInt(localStorage.getItem(STORE_KEY), 10);
    if (saved > 0) target = Math.min(saved, MAX_TARGET);
  } catch (e) { /* storage может быть недоступен */ }

  // ---------- Стили ----------
  const style = document.createElement('style');
  style.textContent = `
    #${BOX_ID} {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      margin-right: 12px;
      vertical-align: middle;
    }
    #${BOX_ID} button, #${BOX_ID} input {
      font: 500 14px "Roboto", "Arial", sans-serif;
      border-radius: 18px;
      outline: none;
    }
    #${BOX_ID} button {
      background: rgba(255,255,255,0.1);
      color: #f1f1f1;
      border: 1px solid rgba(255,255,255,0.2);
      padding: 6px 14px;
      cursor: pointer;
    }
    #${BOX_ID} button:hover { background: rgba(255,255,255,0.2); }
    #${BOX_ID} button.active {
      background: #3ea6ff; color: #0f0f0f; border-color: #3ea6ff; font-weight: 600;
    }
    #${BOX_ID} button.cancel {
      background: #cc3333; border-color: #cc3333; color: #fff;
    }
    #${BOX_ID} input {
      width: 76px;
      background: rgba(255,255,255,0.06);
      color: #f1f1f1;
      border: 1px solid rgba(255,255,255,0.2);
      padding: 6px 10px;
      text-align: center;
    }
    #${BOX_ID} input:focus { border-color: #3ea6ff; }
  `;
  document.head.appendChild(style);

  // ---------- Определение языка ----------
  function isLocalText(text) {
    const letters = text.match(/\p{L}/gu);
    if (!letters) return false;
    const cyr = text.match(/[\u0400-\u04FF]/g);
    return !!cyr && cyr.length / letters.length >= MIN_CYRILLIC_RATIO;
  }

  function getCommentText(thread) {
    const el = thread.querySelector('#content-text') ||
               thread.querySelector('.yt-core-attributed-string');
    return el ? el.textContent : '';
  }

  // ключ для поиска дублей: автор + текст
  function commentKey(thread) {
    const a = thread.querySelector('#author-text');
    const author = a ? (a.getAttribute('href') || a.textContent.trim()) : '';
    return author + '|' + getCommentText(thread).trim();
  }

  // ---------- Сортировка через CSS order ----------
  function resetOrder() {
    if (sortedParent) {
      sortedParent.style.display = '';
      sortedParent.style.flexDirection = '';
      Array.from(sortedParent.children).forEach((c) => {
        c.style.order = '';
        c.style.display = '';
      });
      sortedParent = null;
    }
  }

  // возвращает { total (уникальных), local }
  function applyOrder() {
    const threads = document.querySelectorAll('ytd-comments ytd-comment-thread-renderer');
    if (!active) { resetOrder(); return { total: threads.length, local: 0 }; }
    if (!threads.length) return { total: 0, local: 0 };

    const parent = threads[0].parentElement;
    if (sortedParent && sortedParent !== parent) resetOrder();
    sortedParent = parent;
    parent.style.display = 'flex';
    parent.style.flexDirection = 'column';

    const seen = new Set();
    let local = 0;
    let unique = 0;

    Array.from(parent.children).forEach((child) => {
      if (child.tagName.toLowerCase() === 'ytd-comment-thread-renderer') {
        const key = commentKey(child);
        if (seen.has(key)) {          // дубликат — прячем
          child.style.display = 'none';
          return;
        }
        seen.add(key);
        unique++;

        const isLocal = isLocalText(getCommentText(child));
        if (isLocal) local++;
        child.style.order = isLocal ? '0' : '1';
        child.style.display = (HIDE_FOREIGN && !isLocal) ? 'none' : '';
      } else {
        child.style.order = '999'; // индикатор подгрузки — вниз
      }
    });

    return { total: unique, local };
  }

  // ---------- Обновление кнопок ----------
  function updateUI() {
    const box = document.getElementById(BOX_ID);
    if (!box) return;
    const input = box.querySelector('input');
    const loadBtn = box.querySelector('.ytcf-load');
    const filterBtn = box.querySelector('.ytcf-filter');
    const raw = countThreads();

    if (phase === 'loading') {
      loadBtn.textContent = `Отмена · Esc/N (${raw}/${target})`;
      loadBtn.classList.add('cancel');
      input.disabled = true;
    } else {
      loadBtn.textContent = raw ? `Загрузить (сейчас ${raw})` : 'Загрузить';
      loadBtn.classList.remove('cancel');
      input.disabled = false;
    }

    filterBtn.classList.toggle('active', active);
    if (active) {
      const s = applyOrder();
      filterBtn.textContent = `${BTN_TEXT}: ${s.local} (из ${s.total})`;
    } else {
      filterBtn.textContent = BTN_TEXT;
    }
  }

  // ---------- Подгрузка следующей порции ----------
  function findContinuation() {
    return (
      document.querySelector('ytd-comments ytd-item-section-renderer ytd-continuation-item-renderer') ||
      document.querySelector('ytd-comments ytd-continuation-item-renderer') ||
      document.querySelector('ytd-comments #continuations')
    );
  }

  // имитация «тянем ползунок вниз» (без кликов, чтобы не было дублей)
  async function nudgeLoad(run) {
    window.scrollTo(0, pageBottom());
    await sleep(300);
    if (run !== runId) return;

    window.scrollBy(0, -500);
    await sleep(300);
    if (run !== runId) return;

    window.scrollTo(0, pageBottom());

    const more = findContinuation();
    if (more) {
      more.scrollIntoView({ block: 'end' });
    }
  }

  async function waitForGrowth(prevTotal, run) {
    const start = Date.now();
    while (Date.now() - start < LOAD_TIMEOUT_MS && run === runId) {
      await sleep(300);
      if (countThreads() > prevTotal) return true;
    }
    return false;
  }

  function scrollToHeader() {
    const header = document.querySelector('ytd-comments-header-renderer');
    if (header) header.scrollIntoView({ block: 'start' });
  }

  // ---------- Загрузка комментариев ----------
  async function load(run) {
    phase = 'loading';
    updateUI();

    // ждём первую порцию комментариев
    for (let i = 0; i < 40 && run === runId && countThreads() === 0; i++) {
      const c = document.querySelector('ytd-comments');
      if (c) c.scrollIntoView({ block: 'start' });
      await sleep(500);
    }
    if (run !== runId) return;
    if (countThreads() === 0) {
      phase = 'idle';
      updateUI();
      log('комментариев нет или они отключены');
      return;
    }

    let stalls = 0;
    let reason = 'лимит подгрузок';
    for (let i = 0; i < MAX_ROUNDS && run === runId; i++) {
      const total = countThreads();
      if (active) applyOrder();
      updateUI();
      if (total >= target) { reason = 'достигнута цель'; break; }

      await nudgeLoad(run);
      if (run !== runId) return;

      const grew = await waitForGrowth(total, run);
      if (grew) {
        stalls = 0;
      } else if (++stalls >= MAX_STALLS) {
        reason = 'комментарии кончились или не подгружаются';
        break;
      }
    }

    if (run !== runId) return; // отменено пользователем

    phase = 'idle';
    scrollToHeader();
    updateUI();
    log(`загрузка завершена (${reason}): ${countThreads()} комментариев`);
  }

  function startLoad() {
    const input = document.querySelector(`#${BOX_ID} input`);
    let n = parseInt(input && input.value, 10);
    if (!(n > 0)) n = DEFAULT_TARGET;
    target = Math.min(n, MAX_TARGET);
    if (input) input.value = target;
    try { localStorage.setItem(STORE_KEY, String(target)); } catch (e) { /* ignore */ }

    const run = ++runId;
    load(run);
  }

  function cancelLoad() {
    if (phase !== 'loading') return;
    runId++;
    phase = 'idle';
    scrollToHeader();
    updateUI();
    log('загрузка отменена пользователем');
  }

  // ---------- Горячие клавиши: Esc или N — отмена загрузки ----------
  function isTypingTarget(el) {
    if (!el) return false;
    const tag = el.tagName;
    return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable;
  }

  document.addEventListener('keydown', (e) => {
    if (phase !== 'loading') return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (isTypingTarget(e.target)) return;
    if (!CANCEL_KEYS.includes(e.key)) return;
    e.preventDefault();
    e.stopPropagation();
    cancelLoad();
  }, true);

  // ---------- Панель кнопок ----------
  function injectUI() {
    if (document.getElementById(BOX_ID)) return;

    const header = document.querySelector('ytd-comments-header-renderer');
    if (!header) return;

    const anchor =
      header.querySelector('#sort-menu') ||
      header.querySelector('yt-sort-filter-sub-menu-renderer') ||
      header.querySelector('#additional-section');
    if (!anchor || !anchor.parentNode) return;

    const box = document.createElement('div');
    box.id = BOX_ID;

    const input = document.createElement('input');
    input.type = 'number';
    input.min = '20';
    input.max = String(MAX_TARGET);
    input.step = '100';
    input.value = target;
    input.title = 'Сколько комментариев подгрузить (Enter — начать)';
    // чтобы горячие клавиши YouTube не перехватывали ввод
    ['keydown', 'keypress', 'keyup'].forEach((ev) =>
      input.addEventListener(ev, (e) => e.stopPropagation())
    );
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && phase !== 'loading') startLoad();
    });

    const loadBtn = document.createElement('button');
    loadBtn.className = 'ytcf-load';
    loadBtn.addEventListener('click', () => {
      if (phase === 'loading') cancelLoad();
      else startLoad();
    });

    const filterBtn = document.createElement('button');
    filterBtn.className = 'ytcf-filter';
    filterBtn.addEventListener('click', () => {
      active = !active;
      applyOrder();
      updateUI();
    });

    box.append(input, loadBtn, filterBtn);
    anchor.parentNode.insertBefore(box, anchor);
    updateUI();
  }

  // ---------- Наблюдатель (debounce) ----------
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(() => {
      injectUI();
      if (active && phase !== 'loading') applyOrder(); // новые комментарии при ручном скролле
      updateUI();
    }, 300);
  }

  new MutationObserver(schedule).observe(document.body, { childList: true, subtree: true });

  // ---------- Переход на другое видео ----------
  window.addEventListener('yt-navigate-finish', () => {
    runId++;           // отменяем подгрузку
    active = false;
    phase = 'idle';
    sortedParent = null;
    schedule();
  });

  schedule();
})();